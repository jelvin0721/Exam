<?php $id=trim($_GET['id']); 

$link = mysql_connect('localhost', 'root', 'Masterkey100');
if (!$link) {
    die('Could not connect: ' . mysql_error());
}
mysql_select_db("webdev");
/*echo 'Connected successfully';
*/

$r    = 'select trip_date,driver,time,channel,sale_class,sale_officer from book_head a 
		 left join book_details b on a.id = b.head_id 
		 left join mdc_login c on a.audit_by=c.name
		 where id='.$id;
$head = mysql_query($r,$link);
while ($row  = mysql_fetch_object($head)) {

	$tdate = $row->trip_date;
	$driver = $row->driver;
	$time = $row->time;
	$channel = $row->channel;
	$salecls = $row->sale_class;
	$salesoff = $row->sale_officer;

}

$GLOBALS['sloff'] =$salesoff;
$s   = "select servicing_seller_name,buyer_name,buyer_mobile,pickup_loc,description from book_head a 
		left join book_details b on a.id = b.head_id
		left join mdc_login c on a.audit_by=c.name
		left join projects_name d on a.project = d.id
		where a.id =".$id." 
		union
		select servicing_seller_name,passenger_name,passenger_mobile,pickup_loc,description from book_head a 
		left join book_details b on a.id = b.head_id
		left join mdc_login c on a.audit_by=c.name
		left join projects_name d on a.project = d.id
		left join book_other_passenger e on a.id=e.head_id
		where a.id =".$id;
$data = mysql_query($s,$link);

$e   = "select servicing_seller_name as passenger from book_details  
		where head_id =".$id." 
		union all
		select buyer_name  from book_details  
		where head_id =".$id." 
		union all
		select passenger_name from book_other_passenger
		where head_id =".$id;
$data1 = mysql_query($e,$link);	
require('fpdf.php');

class PDF extends FPDF
{
	// Page header
	//PRIVATE $officer = $saleoff;
	function Header()
	{
	    // Logo
	    $this->Image('image/MDC Homes.jpg',10,11,40);
	    // Arial bold 15
	    $this->SetFont('Arial','B',20);
	    // Move to the right
	    $this->Cell(118);
	    // Title
	    $this->Cell(30,30,'TRIPPING FORM',0,0,'C');

	    $this->Image('image/Richfield.jpg',245,9,40);
	    // Line break
	    $this->Ln(20);
	}

	// Page footer
	function Footer()
	{
	    // Position at 1.5 cm from bottom
	    $this->SetY(-30);
	    // Arial italic 8
	    $this->SetFont('Arial','B',14);
	    // Page number
	    $this->Cell(218,10,'REQUESTED BY:',0,0,'L');
	    $this->Cell(50,10,'APPROVED BY:',0,1,'L');
	    $this->SetFont('Arial','I',12);
	    $this->cell(70,10,'','B',0,'L');
	    $this->cell(10,10,'',0,0,'L');
	    $this->cell(70,10,$GLOBALS['sloff'],'B',0,'C');
	    $this->cell(55,10,'',0,0,'L');
	    $this->cell(70,10,'IVY TAGLE','B',1,'C');

	    $this->cell(70,10,'SALES DIRECTOR',0,0,'C');
	    $this->cell(10,10,'',0,0,'C');
	    $this->cell(70,10,'BROKERS SALES OFFICER',0,0,'C');
	    $this->cell(55,10,'',0,0,'C');
	    $this->cell(70,10,'OFFICER IN CHARGE',0,1,'C');
	}
	function FancyTable($header, $data)
	{
	    // Colors, line width and bold font
	    $this->SetFillColor(115, 38, 115);
	    $this->SetTextColor(255);
	    $this->SetDrawColor(0,0,0);
	    $this->SetLineWidth(.3);
	    $this->SetFont('','B');
	    $this->Ln();
	    // Header
	    $w = array(46, 20, 46, 46, 57, 60);
	    for($i=0;$i<count($header);$i++)
	        $this->Cell($w[$i],7,$header[$i],1,0,'C',true);
	    $this->Ln();
	    // Color and font restoration
	    $this->SetFillColor(255,255,255);
	    $this->SetTextColor(0);
	    $this->SetFont('');
	    // Data
	    $fill = false;
	    $count = mysql_num_rows($data);
		   
	    while ( $row1 = mysql_fetch_object($data))
	    {
	        $this->Cell($w[0],6,$row1->servicing_seller_name,1,0,'C',$fill);
	        $this->Cell($w[1],6,$count,1,0,'C',$fill);
	        $this->Cell($w[2],6,$row1->buyer_name,1,0,'C',$fill);
	        $this->Cell($w[3],6,$row1->buyer_mobile,1,0,'C',$fill);
	        $this->Cell($w[4],6,$row1->pickup_loc,1,0,'C',$fill);
	        $this->Cell($w[5],6,$row1->description,1,0,'C',$fill);
	        $this->Ln();
	        $fill = !$fill;
	    }
	    // Closing line
	    $this->Cell(array_sum($w),0,'','T');
	}
	// Simple table
	function BasicTable($header, $data)
	{
		$w = array(46, 80, 46, 46, 57);
	    $this->Ln();
	    // Header
	    for($i=0;$i<count($header);$i++)
	        $this->Cell($w[$i],9,$header[$i],1,0,'C');
	    $this->Ln();
	    // Data

	    while ( $row2 = mysql_fetch_object($data))
	    {
	        $this->Cell($w[0],9,$row2->passenger,1,0,'C');
	        $this->Cell($w[1],9,'',1,0,'C');
	        $this->Cell($w[2],9,'',1,0,'C');
	        $this->Cell($w[3],9,'',1,0,'C');
	        $this->Cell($w[4],9,'',1,0,'C');
	        
	        $this->Ln();
	        
	    }
	}
}


// Instanciation of inherited class
$pdf = new PDF('L','mm','A4');
$pdf->AliasNbPages();
$pdf->AddPage();
$pdf->SetFont('Times','',12);

$pdf->SetFillColor(25,25,112);
$pdf->SetTextColor(255,255,255);
$pdf->Cell(35,10,'TRIPPING DATE',1,0,'C','true');
$pdf->SetTextColor(0,0,0);
$pdf->Cell(25,10,$tdate,1,0,'C');
$pdf->Cell(79,10,'',0,0);
$pdf->Cell(5,10,'',0,0);
$pdf->SetFillColor(25,25,112);
$pdf->SetTextColor(255,255,255);
$pdf->Cell(35,10,'ASSIGNED PILOT',1,0,'C','true');
$pdf->SetTextColor(0,0,0);
$pdf->Cell(25,10,'',1,0);
$pdf->Cell(70,10,$driver,1,1,'C');

$pdf->SetTextColor(255,255,255);
$pdf->Cell(35,10,'TRIPPING TIME',1,0,'C','true');
$pdf->SetTextColor(0,0,0);
$pdf->Cell(25,10,$time,1,0,'C');
$pdf->Cell(79,10,'',0,0);
$pdf->Cell(5,10,'',0,0);
$pdf->SetTextColor(255,255,255);
$pdf->Cell(35,10,'CHANNEL',1,0,'C','true');
$pdf->SetTextColor(0,0,0);
$pdf->Cell(25,10,$channel,1,0,'C');
$pdf->Cell(70,10,$salecls,1,1,'C');


$header = array('SERVICING CELLER', '# OF PAX', 'PASSENGER NAME', 'CONTACT NUMBER','PICK-UP AT','PROJECT');


$pdf->FancyTable($header,$data);
$pdf->Cell(84,10,'',0,1);
$pdf->SetFillColor(255, 102, 217);
$pdf->SetFont('Times','',25);
$pdf->Cell(275,10,'PASSENGERS LOG SHEET',1,0,'C','true');
$pdf->SetFont('Times','',12);
$header1 = array('COMPLETE NAME', 'ADDRESS', 'MOBILE NO.', 'BODY TEMP','SIGNATURE');
$pdf->BasicTable($header1,$data1);
$pdf->Output();


?>



-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Nov 15, 2020 at 11:25 AM
-- Server version: 5.5.39
-- PHP Version: 5.4.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `webexam`
--

-- --------------------------------------------------------

--
-- Table structure for table `c_current`
--

CREATE TABLE IF NOT EXISTS `c_current` (
`id` bigint(20) NOT NULL,
  `color` varchar(100) NOT NULL,
  `active` bit(1) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `c_current`
--

INSERT INTO `c_current` (`id`, `color`, `active`) VALUES
(1, 'blue.png\r\n', b'1'),
(2, 'default.png\r\n', b'1'),
(3, 'green.png\r\n', b'1'),
(4, 'red.png', b'1');

-- --------------------------------------------------------

--
-- Table structure for table `c_target`
--

CREATE TABLE IF NOT EXISTS `c_target` (
`id` bigint(20) NOT NULL,
  `color` varchar(100) NOT NULL,
  `active` bit(1) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `c_target`
--

INSERT INTO `c_target` (`id`, `color`, `active`) VALUES
(1, 'blue.png', b'1'),
(2, 'default.png\r\n', b'1'),
(3, 'green.png\r\n', b'1'),
(4, 'red.png', b'1');

-- --------------------------------------------------------

--
-- Table structure for table `main`
--

CREATE TABLE IF NOT EXISTS `main` (
  `plate_no` varchar(25) NOT NULL,
  `c_current` varchar(25) NOT NULL,
  `c_target` varchar(25) NOT NULL,
  `status` varchar(11) NOT NULL,
  `audit_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `main`
--

INSERT INTO `main` (`plate_no`, `c_current`, `c_target`, `status`, `audit_date`) VALUES
('dfg 123', 'blue.png', 'green.png', 'Completed', '2020-11-15 14:03:32'),
('dfg 124', 'red.png', 'green.png', 'Completed', '2020-11-15 14:05:30'),
('dfg 125', 'red.png', 'green.png', 'In-Progress', '2020-11-15 14:05:37'),
('dfg 126', 'green.png', 'red.png', 'In-Progress', '2020-11-15 14:05:58');

-- --------------------------------------------------------

--
-- Table structure for table `status`
--

CREATE TABLE IF NOT EXISTS `status` (
`id` int(11) NOT NULL,
  `name` varchar(11) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `status`
--

INSERT INTO `status` (`id`, `name`) VALUES
(1, 'On-queue'),
(2, 'In-Progress'),
(3, 'Completed');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `c_current`
--
ALTER TABLE `c_current`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `c_target`
--
ALTER TABLE `c_target`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `main`
--
ALTER TABLE `main`
 ADD PRIMARY KEY (`plate_no`);

--
-- Indexes for table `status`
--
ALTER TABLE `status`
 ADD PRIMARY KEY (`id`,`name`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `c_current`
--
ALTER TABLE `c_current`
MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `c_target`
--
ALTER TABLE `c_target`
MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `status`
--
ALTER TABLE `status`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

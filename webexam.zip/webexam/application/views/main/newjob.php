<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <title>Hello, world!</title>
    <style type="text/css">
    	h1{
    		color: grey;
    	  }
    
    	ul a:hover{
		  color: #000 !important;
		}
		nav li{
		    text-align: center;
		    text-transform: uppercase;
		    
		}
		li > a:after{
		    content: '';
		    display: block;
		    height: 1.5px;
		    background: #000;
		    transform: scaleX(0);
		    transition: transform .3s;
		}
		li > a:hover:after{
		    transform: scaleX(1);
		    transition: transform .3s;
		}
		nav .active{
	      color: #000 !important;
	     transform: scaleX(1);
	     text-decoration: underline;
	     
		}
		.nav-link 
		{
			 color: #fff !important;
		}
	
		.jumbotron{
			margin-bottom: 0px;
		}
		.navbar
		{
			background-color: #ea6a5b;
		}
		.jobnew
		{
			margin-top: 50px;
		}
		.hd
		{
			margin-top: 50px;
		}
		.bttn
		{
			background-color: #ea6a5b;
		}
    </style>
  </head>
  <body>
 <!-- header -->
    <div class="jumbotron jumbotron-fluid">
	  <div class="container">
	    <h1 class="text-center">JUAN'S AUTO PAINT</h1>
	  </div>
	</div><!-- end of header -->
 <!--navbar-->
	<nav class="navbar navbar-expand-md navbar-collapse">
	  <div class="collapse navbar-collapse" id="navbarNav">
	    <ul class="navbar-nav">
	      <li class="nav-item ">
	        <a class="nav-link active " href="<?php echo base_url(); ?>">New Paint Job<span class="sr-only">(current)</span></a>
	      </li>
	      <li class="nav-item">
	        <a class="nav-link" href="<?php echo site_url('main/jobs'); ?>">Paint Jobs</a>
	      </li>
	      
	    </ul>
  	  </div>
	</nav><!-- end of nav -->
	<div class="container">
		<div class='row  d-flex justify-content-center '>
			<h3 class="text-center jobnew">New Paint Job</h3>
		</div>
		<div class='row  d-flex justify-content-center hd'>
			<img src="<?php echo base_url('image/car/default.png'); ?>" class="rounded float-left" alt="..." id='car_current'>
			<img src="<?php echo base_url('image/car/arraw.png'); ?>" class="rounded float-left w-10 p-3" alt="...">
			<img src="<?php echo base_url('image/car/default.png'); ?>" class="rounded float-right" alt="..." id='car_target'>
		</div>
		<div class='row d-flex flex-column hd'>
			<div class='p-1'><h4>Car Details</h4></div>		
			<form id='frmmain'>
			<div class='p-1'>
				<div class="form-group row">
				    <label for="colFormLabelSm" class="col-sm-2 col-form-label col-form-label-sm">Plate No.</label>
				    <div class="col-sm-3">
				      <input type="text" class="form-control form-control-sm" id="txtplate" placeholder="">
				    </div>
			  	</div>
			</div>
			<div class='p-1'>
				<div class="form-group row">
				    <label for="colFormLabelSm" class="col-sm-2 col-form-label col-form-label-sm">Current Color</label>
				    <div class="col-sm-3">
				      <select class="form-control  form-control-sm" id="current">
				      		<option value="" selected></option>
				      	<?php foreach ($current as $row) { ?>
				      		<option value="<?php echo $row->color; ?>"><?php echo $row->color; ?></option>
				      	<?php  	} ?>	
				      </select>
				    </div>
			  	</div>
			</div>		
		    <div class='p-1'>
				<div class="form-group row">
				    <label for="colFormLabelSm" class="col-sm-2 col-form-label col-form-label-sm">Target Color</label>
				    <div class="col-sm-3">
				      <select class="form-control  form-control-sm" id="target">
				      		<option value="" selected></option>
				      	<?php foreach ($target as $row1) { ?>
				      		<option value="<?php echo $row1->color; ?>"><?php echo $row1->color; ?></option>
				      	<?php  	} ?>
				      </select>
				    </div>
			  	</div>
			</div> 
			<div class='p-1'>
				<button type="button" id='btnsub' class="btn btn-lg bttn">Submit</button>
			</div>
		</form>	   	
		</div>	
		</div>
	</div>
		
		
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <script type="text/javascript">
    	

/* */
    	$('#current').change(function() {
    		var color = $(this).val();
  			 $("#car_current").attr("src", "<?php echo base_url('image/car/'); ?>"+color);
		});
		$('#target').change(function() {
    		var color = $(this).val();
    		var cc    =	$("#current").val();
    		//alert($.trim(cc)+' '+$.trim(color));
    		if( $.trim(cc) != $.trim(color))
    		{
  			 $("#car_target").attr("src", "<?php echo base_url('image/car/'); ?>"+color);
    		}
    		else
    		{
    		  alert('Choose a Same color of current!');
    		  $(this).attr('selected', 'selected');
    		}
		});
		$("#btnsub").click(function(){
			  $.post("<?php echo site_url('/main/insert'); ?>",
			  {
			    plateno: $("#txtplate").val(),
			    current: $("#current").val(),
			    target : $("#target").val(),
			  },
			  function(data, status){
			    alert("Data: " + data + "\nStatus: " + status);
			  });
			});
    </script>
  </body>
</html>

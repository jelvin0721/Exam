<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <title>Hello, world!</title>
    <style type="text/css">
    	h1{
    		color: grey;
    	  }
    
    	ul a:hover{
		  color: #000 !important;
		}
		nav li{
		    text-align: center;
		    text-transform: uppercase;
		    
		}
		li > a:after{
		    content: '';
		    display: block;
		    height: 1.5px;
		    background: #000;
		    transform: scaleX(0);
		    transition: transform .3s;
		}
		li > a:hover:after{
		    transform: scaleX(1);
		    transition: transform .3s;
		}
		nav .active{
	      color: #000 !important;
	     transform: scaleX(1);
	     text-decoration: underline;
	     
		}
		.nav-link 
		{
			 color: #fff !important;
		}
	
		.jumbotron{
			margin-bottom: 0px;
		}
		.navbar
		{
			background-color: #ea6a5b;
		}
		.jobnew
		{
			margin-top: 50px;
		}
		.hd
		{
			margin-top: 50px;
		}
		
		.borderless td, .borderless th {
		    border: none;

		    padding: 5px; 

		}

    </style>
  </head>
  <body>
 <!-- header -->
    <div class="jumbotron jumbotron-fluid">
	  <div class="container">
	    <h1 class="text-center">JUAN'S AUTO PAINT</h1>
	  </div>
	</div><!-- end of header -->
 <!--navbar-->
	<nav class="navbar navbar-expand-md navbar-collapse">
	  <div class="collapse navbar-collapse" id="navbarNav">
	    <ul class="navbar-nav">
	      <li class="nav-item ">
	        <a class="nav-link  " href="<?php echo base_url(); ?>">New Paint Job<span class="sr-only">(current)</span></a>
	      </li>
	      <li class="nav-item">
	        <a class="nav-link active" href="<?php echo site_url('main/jobs'); ?>">Paint Jobs</a>
	      </li>
	      
	    </ul>
  	  </div>
	</nav><!-- end of nav -->
	<div class="container">
		<div class='row  d-flex justify-content-center '>
			<h3 class="text-center jobnew">Paint Jobs</h3>
		</div>
		<div class='row hd'>
			<div class="col-lg-9">
			<h5>Paint Jobs in Progress</h5>
		
			<table class="table table-bordered">
			  <thead style="background-color: #dddddd">
			    <tr>
			      <th scope="col">Plate No.</th>
			      <th scope="col">Current Color</th>
			      <th scope="col">Target Color</th>
			      <th scope="col">Action</th>
			    </tr>
			  </thead>
			  <tbody id='tbprog'> </tbody>
			</table>
			</div>
			<div class="col-lg-3">
		    <h5>&nbsp;&nbsp;&nbsp;</h5>
			<table class="table borderless">
			  <thead>
			    <tr>
			      <th  colspan="2" style="background-color: #ea6a5b;">SHOP PREPORMANCE</th>
			    </tr>
			  </thead>
			  <tbody style="background-color:#eeeeee;" id='counterall'>
			  	 
			    
			  </tbody>
			</table>
			</div>
	</div>
	<div class="row hd">
		<div class="col-lg-9">
			<h5>Paint Queue</h5>
			<table class="table table-bordered">
			  <thead style="background-color: #dddddd">
			    <tr>
			      <th scope="col">Plate No.</th>
			      <th scope="col">Current Color</th>
			      <th colspan="2">Target Color</th>
			    </tr>
			  </thead>
			  <tbody id='tbque'></tbody>
			</table>
			</div>
			<div class="col-lg-3">
			</div>
	</div>
		
		
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <script type="text/javascript">    	
    	//update status completed
    	function neknek(rest)
    	{
    		//alert(rest);
    		$.post("<?php echo site_url('/main/done'); ?>",
    			{
    				idstatus : rest
    			},
			 
			  function(data2, status2){
			   alert("\nStatus: " + status1);
			   //$("#counterall").html(data2);
				   //progress
	    	/*	$.post("<?php echo site_url('/main/selectprog'); ?>",
				 
				  function(data3, status3){
				   /// alert("Data: " + data1 + "\nStatus: " + status1);
				    $("#tbprog").html(data1);
				  });*/
			  });
    	}
    	//quee
			  $.post("<?php echo site_url('/main/selectcur'); ?>",
			 
			  function(data, status){
			    /*alert("Data: " + data + "\nStatus: " + status);*/
			    $("#tbque").html(data);
			  });
		//progress
    		$.post("<?php echo site_url('/main/selectprog'); ?>",
			 
			  function(data1, status1){
			   /// alert("Data: " + data1 + "\nStatus: " + status1);
			    $("#tbprog").html(data1);
			  });
    	//counter
    	$.post("<?php echo site_url('/main/countercomplete'); ?>",
			 
			  function(data2, status2){
			   /// alert("Data: " + data1 + "\nStatus: " + status1);
			    $("#counterall").html(data2);
			  });
    	
 /*   	var counter = 0;
var myInterval = setInterval(function () {
  ++counter;
}, 1000);*/
        //update every 5 seconds
        var counter = 0;
		var interval = setInterval(function() {
	    ++counter;
	    // Display 'counter' wherever you want to display it.
	    if (counter == 5) {
	        // Display a login box
	        $.post("<?php echo site_url('/main/updatestatonqueue'); ?>",
			 
			  function(data1, status1){
			   /// alert("Data: " + data1 + "\nStatus: " + status1);
			   // $("#tbque").html(data1);
			  });
	         $.post("<?php echo site_url('/main/selectcur'); ?>",
			 
			  function(data, status){
			    /*alert("Data: " + data + "\nStatus: " + status);*/
			    $("#tbque").html(data);
			  });
		//progress
    		$.post("<?php echo site_url('/main/selectprog'); ?>",
			 
			  function(data1, status1){
			   /// alert("Data: " + data1 + "\nStatus: " + status1);
			    $("#tbprog").html(data1);
			  });
    		//counter
    	$.post("<?php echo site_url('/main/countercomplete'); ?>",
			 
			  function(data2, status2){
			   /// alert("Data: " + data1 + "\nStatus: " + status1);
			    $("#counterall").html(data2);
			  });
	    }
	}, 1000);
    </script>
  </body>
</html>

<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Main extends CI_Controller {

	public function __construct()
    {
        parent::__construct();
        error_reporting(0);
   		$this->load->model('M_main');
    }  

	public function index($msg='')
	{
		

		$data['target']  	= $this->M_main->c_target();
		$data['current']	= $this->M_main->c_current();
		$this->load->view('main/newjob',$data);
		
	}
	public function insert()
	{

		$data=array('plate'=>$this->input->post('plateno'),
			   	    'curre'=>$this->input->post('current'),
					'targe'=>$this->input->post('target')
				   );
	/*	var_dump(expression)
		die();
*/		$this->M_main->inserthead($data);

	}
	/*task job*/
	public function jobs()
	{
		$data['target']  	= $this->M_main->c_target();
		$data['current']	= $this->M_main->c_current();
		$this->load->view('main/taskjob',$data);
	}
    public function selectcur()
    {
    	$qry=$this->M_main->squeue();
    	$num=count($qry);    	
    	if ($num > 0) 
    	{
		    	foreach ($qry as $row) {
		    		$ex=explode('.', $row->c_current);
		    		$ex1=explode('.', $row->c_target);
		    		echo $data = '<tr>'.
					      '<td >'.$row->plate_no.'</td>'.
					      '<td >'.$ex[0].'</td>'.
					      '<td colspan="2">'.$ex1[0].'</td>'.
					    '</tr>';
					
					
		    	}
		}
    	else
		{
				echo $data = '<tr>'.
			      '<th colspan="4" class="text-center">No Data For Queue!</th>'.
			    '</tr>';

		}
    }
    

	public function selectprog()
    {
    	$qry=$this->M_main->sprogres();
    	$num=count($qry);    	
    	if ($num > 0) 
    	{
	    	foreach ($qry as $row)
	    	{
	    		$ex=explode('.', $row->c_current);
		    		$ex1=explode('.', $row->c_target);
	    		echo $data = '<tr>'.
				      '<td >'.$row->plate_no.'</td>'.
				      '<td >'.$ex[0].'</td>'.
				      '<td >'.$ex1[0].'</td>'.
				      '<td ><button type="button" class="btn btn-light" onClick="neknek('."'".trim($row->plate_no)."'".')">Mark as Completed</button></td>'.
				    '</tr>';
	    	}
    	}
		else
		{
				echo $data = '<tr>'.
			      '<th colspan="4" class="text-center">No Data For In Progress!</th>'.
			    '</tr>';
  
		}
    	      
    }		   
    public function updatestatonqueue()
    {
    	$qry=$this->M_main->update123(); 

    } 
    public function countercomplete()
    {	

    	$qry= $this->M_main->counterall();
    	foreach ($qry as $key) {
    	echo $data=	'<tr>
					      <td scope="col">Total Cars Painted:</td>
					      <th>'.$key->countall.'
							</th>
					    </tr>
					    <tr>
					      <th colspan="2" >Breakdown:</th>
					    </tr>
					     <tr>
					      <td class="text-center" scope="col">Blue</td> 
					      <th class="">'.$key->blue.'</th>
					    </tr>
					    <tr>
					      <td class="text-center" scope="row">Red</td>
					      <th class="">'.$key->red.'</th>
					    </tr>
					     <tr>
					      <td class="text-center" scope="col">Green</td>
					      <th class="">'.$key->green.'</th>
					</tr>';
    	}
    	
    }
    public function done()
    {
    	$data1=$this->input->post('idstatus');
    	$this->M_main->update1($data1);
    	echo 'done';
    }

}


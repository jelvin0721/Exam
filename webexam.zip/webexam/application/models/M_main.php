<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class M_main extends CI_Model {

        public function __construct()
        {
            parent::__construct();
            $this->load->database('default');
        }
       
        /*main */
        public function c_target()
        {
            $query=$this->db->get('c_target');

            return $query->result();
        }
        public function c_current()
        {
            $query=$this->db->get('c_current');
            
            return $query->result();
        }
        
        //insert data
        public function inserthead($data=array())
        {

            $data1 = array(                       
                            'plate_no'    => trim($data['plate']),
                            'c_current'   => trim($data['curre']),
                            'c_target'    => trim($data['targe']),
                            'status'      =>'On-queue'
                        );
           /* var_dump($data1);*/
            $this->db->set('audit_date', 'NOW()', FALSE);
            $this->db->insert('main', $data1);
            
        
        }
      
        /*new jobs*/
        public function squeue()
        {
            $this->db->where('status','On-queue');
            $query=$this->db->get('main');
            return $query->result();
        }
         public function sprogres()
        {
            $this->db->where('status','In-Progress');
            $query=$this->db->get('main');
            return $query->result();
        }

        public function update123()
        {
         
            $sql="update main set status='In-Progress' where status='On-queue'";
            $query=@$this->db->query($sql);
            return 1;
        }
           public function update1($data)
        {
         
            $sql="update main set status='Completed' where plate_no='".$data."'";
            $query=@$this->db->query($sql);
            return 1;
        }
        public function counterall()
        {
            $sql="SELECT
                (select count(c_target) from main where status='Completed') as countall,
                (select count(c_target) from main where c_target='blue.png' and status='Completed') as blue,
                (select count(c_target) from main where c_target='red.png'and status='Completed') as red,
                (select count(c_target) from main where c_target='green.png' and status='Completed') as green";
            $query=@$this->db->query($sql);
            return $query->result();
        }

}
?>